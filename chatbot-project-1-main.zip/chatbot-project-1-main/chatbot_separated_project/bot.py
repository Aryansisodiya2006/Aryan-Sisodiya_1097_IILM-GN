import requests
import json

API_KEY = "use your own"
MODEL = "meta-llama/llama-3.1-8b-instruct"
URL = "https://openrouter.ai/api/v1/chat/completions"

def chat_with_bot(user_message, conversation_history=[]):
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    messages = conversation_history + [{"role": "user", "content": user_message}]

    payload = {
        "model": MODEL,
        "messages": messages,
        "max_tokens": 150,
        "temperature": 0.7
    }

    try:
        response = requests.post(URL, headers=headers, data=json.dumps(payload))

        if response.status_code == 200:
            data = response.json()
            bot_reply = data["choices"][0]["message"]["content"]
            conversation_history.append({"role": "user", "content": user_message})
            conversation_history.append({"role": "assistant", "content": bot_reply})
            return bot_reply, conversation_history
        else:
            return f"API Error: {response.status_code} - {response.text}", conversation_history

    except requests.exceptions.RequestException as e:
        return f"Network Error: {str(e)}", conversation_history
