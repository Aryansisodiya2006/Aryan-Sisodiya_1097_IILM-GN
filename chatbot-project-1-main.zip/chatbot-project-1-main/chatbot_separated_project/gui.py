import tkinter as tk
from tkinter import scrolledtext
from bot import chat_with_bot

class ChatbotGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("AI Chatbot - OpenRouter")
        self.root.geometry("600x700")
        self.root.configure(bg="#1e1e1e")

        self.history = []

        tk.Label(
            root,
            text="AI Chatbot",
            bg="#1e1e1e",
            fg="white",
            font=("Arial", 20, "bold")
        ).pack(pady=10)

        self.chat_area = scrolledtext.ScrolledText(
            root,
            wrap=tk.WORD,
            font=("Arial", 12),
            bg="#2b2b2b",
            fg="white",
            state="disabled"
        )
        self.chat_area.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        self.input_box = tk.Entry(
            root,
            font=("Arial", 14),
            bg="#333333",
            fg="white",
            insertbackground="white"
        )
        self.input_box.pack(padx=10, pady=10, fill=tk.X)
        self.input_box.bind("<Return>", self.send_message)

        tk.Button(
            root,
            text="Send",
            font=("Arial", 12, "bold"),
            bg="#4CAF50",
            fg="white",
            padx=10,
            pady=5,
            command=self.send_message
        ).pack(pady=5)

    def send_message(self, event=None):
        user_message = self.input_box.get().strip()
        if user_message == "":
            return

        self.display_message(f"You: {user_message}\n")
        self.input_box.delete(0, tk.END)

        bot_reply, self.history = chat_with_bot(user_message, self.history)
        self.display_message(f"Bot: {bot_reply}\n\n")

    def display_message(self, msg):
        self.chat_area.configure(state="normal")
        self.chat_area.insert(tk.END, msg)
        self.chat_area.configure(state="disabled")
        self.chat_area.see(tk.END)
